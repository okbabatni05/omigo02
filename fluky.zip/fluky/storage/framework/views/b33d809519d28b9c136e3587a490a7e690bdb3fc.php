<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
<div class="card-body">
    <form id="globalConfigEdit">
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label><?php echo e($model->key); ?></label>
                    <input type="hidden" id="id" value="<?php echo e($model->id); ?>">
                    <input type="hidden" id="key" value="<?php echo e($model->key); ?>">
                    <?php if($model->key == 'THEME_COLOR'): ?>
                        <input type="color" id="value" value="<?php echo e($model->value); ?>" class="form-control" required>
                    <?php elseif($model->key == 'LOGO' || $model->key == 'FAVICON'): ?>
                        <input type="file" id="value" value="<?php echo e($model->value); ?>" class="form-control"
                            accept=".png" required>
                    <?php elseif($model->key == 'AUTH_MODE' || $model->key == 'PAYMENT_MODE'): ?>
                        <select id="value" class="form-control">
                            <option value="enabled" <?php if($model->value == 'enabled'): ?> selected <?php endif; ?>>Enabled</option>
                            <option value="disabled" <?php if($model->value == 'disabled'): ?> selected <?php endif; ?>>Disabled</option>
                        </select>
                    <?php elseif($model->key == 'DEFAULT_THEME'): ?>
                        <select id="value" class="form-control">
                            <option value="light" <?php if($model->value == 'light'): ?> selected <?php endif; ?>>Light</option>
                            <option value="dark" <?php if($model->value == 'dark'): ?> selected <?php endif; ?>>Dark</option>
                        </select>
                    <?php elseif($model->key == 'CURRENCY'): ?>
                        <select id="value" class="form-control">
                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($currency->code); ?>" <?php if($model->value == $currency->code): ?> selected <?php endif; ?>>
                                    <?php echo e($currency->name . ' - ' . $currency->code . ' - ' . $currency->symbol); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php else: ?>
                        <input type="text" id="value" value="<?php echo e($model->value); ?>" class="form-control"
                            placeholder="Enter Value" maxlength="255" required>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <div class="callout callout-info">
                        <h5>Description</h5>

                        <p><?php echo e($model->description); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <?php if($model->key == 'LOGO' || $model->key == 'FAVICON'): ?>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Preview</label>
                        <div class="preview">
                            <img src="<?php echo e(asset('storage/images/' . $model->key . '.png')); ?>"
                                alt="<?php echo e($model->key); ?>">
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <button type="submit" id="save" class="btn btn-primary">Save</button>
        <a href="<?php echo e(route('global-config')); ?>"><button type="button" class="btn btn-default">Cancel</button></a>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.0.0_9_8_13_08\resources\views/admin/global-config/edit.blade.php ENDPATH**/ ?>