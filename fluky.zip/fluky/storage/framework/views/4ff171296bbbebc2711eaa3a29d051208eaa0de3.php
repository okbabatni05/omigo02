<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <?php if(getSetting('PAYMENT_MODE') == 'disabled'): ?>
        <span class="badge badge-warning p-2 mb-3">The payment mode is disabled, <a href="<?php echo e(route('global-config')); ?>">enable</a> now to accept payments.</span>
      <?php endif; ?>
      <table class="table table-bordered table-striped table-hover">
        <thead>
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Amount</th>
          <th>Currency</th>
          <th>Type</th>
          <th>Gateway</th>
          <th>Transaction ID</th>
          <th>Plan Start Date</th>
          <th>Plan End Date</th>
        </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($value->id); ?></td>
            <td><?php echo e($value->username); ?></td>
            <td><?php echo e($value->amount); ?></td>
            <td><?php echo e($value->currency); ?></td>
            <td>
              <?php if($value->type == "monthly"): ?>
                <span class="badge badge-info">Monthly</span>
              <?php else: ?>
                <span class="badge badge-success">Yearly</span>
              <?php endif; ?>
            </td>
            <td><?php echo e(ucfirst($value->gateway)); ?></td>
            <td><?php echo e($value->transaction_id); ?></td>
            <td><?php echo e($value->plan_start_date); ?></td>
            <td><?php echo e($value->plan_end_date); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Amount</th>
          <th>Currency</th>
          <th>Type</th>
          <th>Gateway</th>
          <th>Transaction ID</th>
          <th>Plan Start Date</th>
          <th>Plan End Date</th>
        </tr>
        </tfoot>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.0.0\resources\views/admin/income.blade.php ENDPATH**/ ?>