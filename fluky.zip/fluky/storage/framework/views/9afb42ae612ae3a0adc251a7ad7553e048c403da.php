<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card">
                <!-- <div class="card-header"><?php echo e(__('Register')); ?></div> -->

                <div class="card-body auth-section">
                    <div class="row">
                      <div class="col-12 text-center mt-2 mb-3">
                        <i class="fa fa-user-plus change-password-icon"></i>
                      </div>
                    </div>
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <!-- <label for="username" class="col-md-4 col-form-label "><?php echo e(__('Username')); ?></label> -->

                            <div class="col-md-12 p-0">
                                <input id="username" type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" placeholder="<?php echo e(__('Username')); ?>" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>
                                <span class="focus-border"></span>
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <!-- <label for="email" class="col-md-4 col-form-label "><?php echo e(__('E-Mail Address')); ?></label> -->

                            <div class="col-md-12 p-0">
                                <input id="email" placeholder="<?php echo e(__('E-Mail Address')); ?>" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                                <span class="focus-border"></span>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <!-- <label for="gender" class="col-md-4 col-form-label"><?php echo e(__('Gender')); ?></label> -->

                            <div class="col-md-12 p-0">
                                <select id="gender" placeholder="<?php echo e(__('Gender')); ?>" class="form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gender" required>
                                    <option value="">--Select--</option>
                                    <option value="male" <?php echo e(old('gender') == 'mae' ? "selected": ""); ?>>Male</option>
                                    <option value="female" <?php echo e(old('gender') == 'female' ? "selected": ""); ?>>Female</option>
                                </select>
                                <span class="focus-border"></span>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <!-- <label for="password" class="col-md-4 col-form-label "><?php echo e(__('Password')); ?></label> -->

                            <div class="col-md-12 p-0">
                                <input id="password" placeholder="<?php echo e(__('Password')); ?>" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                                <span class="focus-border"></span>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <!-- <label for="password-confirm" class="col-md-4 col-form-label "><?php echo e(__('Confirm Password')); ?></label> -->

                            <div class="col-md-12 p-0">
                                <input id="password-confirm" placeholder="<?php echo e(__('Confirm Password')); ?>" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                <span class="focus-border"></span>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label>
                                By clicking Register you certify that you are over
                                18 years old and accept our <a href="http://localhost:8000/terms-and-conditions" target="_blank">Terms &amp; Conditions</a> and our
                                <a href="http://localhost:8000/privacy-policy" target="_blank">Privacy Policy</a>.
                            </label>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-12 p-0">
                                <button type="submit" class="btn btn-theme btn-lg w-100">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky_2.0.0_9_8_12_08\resources\views/auth/register.blade.php ENDPATH**/ ?>